<?php

session_start();

echo $_SESSION["auto_room_param"];

?>