<?php

include "zerver_entrance.php";
session_start();
error_reporting(0);

$essay_answer = $_POST["essay_answer"];
$question_id = $_POST["question_id"];

$email = $_SESSION["curr_email_user"];

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql = "INSERT INTO student_answers (answer, question_id, owner_student, time_of_submission, grades, checked, system_confidence, re_eval)
    VALUES ('$essay_answer', '$question_id', '$email', CURRENT_TIMESTAMP, 0, 0, '-1', 0)";
    // use exec() because no results are returned
    $conn->exec($sql);
  } catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
  }
  $conn = null;

?>