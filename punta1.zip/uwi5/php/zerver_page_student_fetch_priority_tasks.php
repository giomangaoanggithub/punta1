<?php

include 'zerver_entrance.php';

session_start();

error_reporting(0);

$email = $_SESSION["curr_email_user"];

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $conn->prepare("SELECT * FROM (((SELECT * FROM created_questions GROUP BY question_id) as T1 LEFT JOIN (SELECT * FROM student_answers WHERE owner_student = '$email') as T2 ON T1.question_id = T2.question_id) LEFT JOIN teacher_student_connection ON T1.owner_teacher = teacher_student_connection.teacher_email) WHERE t_s_connection = '1' AND student_email = '$email' AND publish = '1' GROUP BY T1.question_id;");
    $stmt->execute();
  
    // set the resulting array to associative
    $result = $stmt->FetchAll(PDO::FETCH_ASSOC);

    echo json_encode($result);
  } catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
  }
  $conn = null;
?>